<footer data-aos="zoom-in-up" class="footer-dark">
        <div class="container">
            <div class="row">
                <div class="col-md-6 item text">
                    <h3>Inspire Club</h3>
                    <p>"Science is simply the word we use to describe a method of organising our curiosity". INSPIRE which stands for INNOVATION FOR SCIENTIFIC 
                        PROSPERITY IN INTELLECTUALITY, RESEARCH AND EDUCATION ,aims at promoting inquisitiveness among the students and inculcate science temper 
                        among them as well as gives a platform to students who want to pursue scientific career in future. Being the only science club of NITR 
                        we always target to get one million original ideas/innovations rotted in science and societal applications to faster in culture of
                         creativity and innovative thoughts among the school students and students of NITR. We always do out best to put latest scientific
                          research into teaching and inspire students invention and creativity with realistic results of scientific research in order to
                           promote better teaching quality and add great vitality in teaching.</p>
                </div>
                <div class="col item social">
                <a href="https://m.facebook.com/pages/category/Science-Website/Inspirenitr-109972063893357/"><i class="icon ion-social-facebook"></i></a>
                <a href="https://in.linkedin.com/company/inspire-nitr?trk=public_profile_topcard-current-company"><i class="icon ion-social-linkedin-outline"></i></a>
                <a href="https://www.instagram.com/inspire.nitr/?hl=en"><i class="icon ion-social-instagram"></i></a></div>
            </div>
            <p class="copyright">Inspire Club © 2021</p>
            <p class="copyright">Designed By Jagannath Behera</p>
        </div>
    </footer>